def first(iterable):
    return next(iter(iterable))
